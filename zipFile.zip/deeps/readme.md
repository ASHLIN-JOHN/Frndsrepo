steps to use:

1. In terminal run : npm init -y
2. next run : npm install express dotenv @neondatabase/serverless
3.